// Stub implementation
#include <zephyr/kernel.h>

void mcp3204_pointing_init(void) {
    printk("MCP3204 pointing driver initialized\n");
}
